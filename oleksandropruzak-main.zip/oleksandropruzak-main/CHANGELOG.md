# SmartNotes Changelog

## 2025-11-26
- Added tkinter GUI improvements: sorting, duplicate validation, search highlight — `[KAN-11]`.
- Introduced Kanban board snapshot generator and image assets — `[KAN-07]`.
- Earlier commits: CLI foundation, JSON storage, PDF exporter, docs, reports.

> Для детальної історії використовуйте `git log --oneline`.

