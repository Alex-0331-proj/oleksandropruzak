# Screenshots placeholder

Додайте сюди знімки екранів Kanban-дошки, відкритих Pull Request та історії комітів. 

Файли, які посилаються у звіті:
- `kanban_smartnotes.png`
- `git_history.png`
- `pr_overview.png`

